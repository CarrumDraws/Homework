Will
  2:24 PM
@channel Hello Team,
Since we didn't do the frontend portion for yesterday's assignment, you don't have to complete the frontend portion for today's assignment either. Instead, you should focus on improving the frontend UI for your solo project
For the validation part for today's assignment, please use either validator or yup .
For your solo project, please use static serving of plain HTML/CSS/JS files and don't use template engines.

Skipping Question 1 Step 3 (Will said to ignore it)