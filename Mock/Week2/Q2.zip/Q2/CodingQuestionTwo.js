// 1281. US Population

// Fetch data from the API https://datausa.io/api/data?drilldowns=Nation&measures=Population and display it in a table, matching the given styling.

// Add a dropdown that lets you select the order of the years.
// Add a final row that displays the average population of all years (rounded down).

let tbody = document.getElementsByTagName("tbody")[0];
let select = document.getElementsByTagName("select")[0];
select.addEventListener("click", (data) => {
  console.log(select.options.selectedIndex); // Get Selected data
  fetchData(select.options.selectedIndex);
});

// order,
// 0 = Desc
// 1 = Asc
function fetchData(order = 0) {
  fetch("https://datausa.io/api/data?drilldowns=Nation&measures=Population")
    .then((res) => res.json())
    .then((data) => {
      console.log(data.data);
      inputData(data.data, order);
      return data.data;
    })
    .catch((err) => console.log(err));
}

fetchData();

function inputData(pop, order) {
  tbody.innerHTML = null;
  let avg = 0;
  if (order)
    pop.sort((a, b) => {
      return a.Year - b.Year;
    });
  for (let i = 0; i < pop.length; i++) {
    let tr = document.createElement("tr");
    let year = document.createElement("td");
    let population = document.createElement("td");

    year.innerHTML = pop[i].Year;
    population.innerHTML = pop[i].Population;

    avg += pop[i].Population;

    tr.append(year);
    tr.append(population);
    tbody.append(tr);
  }

  let tr = document.createElement("tr");
  let year = document.createElement("td");
  let population = document.createElement("td");

  year.innerHTML = "Average";
  population.innerHTML = Math.floor(avg / pop.length);

  tr.append(year);
  tr.append(population);
  tbody.append(tr);
}
